<template>
  <div class="home-feature">
    <a href="http://adi-v3.dev">
      <img src="~assets/images/home/recommend_bg.jpg" alt="">
    </a>
  </div>
</template>

<script>
    export default {
        name: "HomeFeatureView"
    }
</script>

<style scoped>
  .home-feature img{
    width: 100%;
  }
</style>
