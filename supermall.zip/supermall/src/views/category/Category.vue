<template>
  <h2>品类</h2>
</template>

<script>
    export default {
        name: "Category"
    }
</script>

<style scoped>

</style>
